const initState = {
    products: [
        {id: 1, name: ' t-shirt summer season', image: '1.jpg', price: 20, discount: 2, discountPrice: 20  - 2 / 100 * 20, quantity: 1, dec:"shirts for summer season"},
        {id: 2, name: 't-shirt', image: '2.jpg', price: 30, discount: 5, discountPrice: 30  - 5 / 100 * 30, quantity: 1, },
        {id: 3, name: 't-shirt', image: '3.jpg', price: 15, discount: 3, discountPrice: 15  - 3 / 100 * 15, quantity: 1,},
        {id: 4, name: 'denim shirt', image: '4.jpg', price: 50, discount: 4, discountPrice: 50  - 4 / 100 * 50, quantity: 1, },
        {id: 5, name: 'shirts', image: '5.jpg', price: 25, discount: 2, discountPrice: 25  - 2 / 100 * 25, quantity: 1,},
        {id: 7, name: 't-shirts', image: '7.jpg', price: 35, discount: 2, discountPrice: 35  - 2 / 100 * 35, quantity: 1,},
        {id: 8, name: 'shirts', image: '8.jpg', price: 80, discount: 7, discountPrice: 80  - 7 / 100 * 80, quantity: 1, },
        {id: 9, name: 'jacket ', image: '9.jpg', price: 95, discount: 4, discountPrice: 95  - 4 / 100 * 95, quantity: 1}

    ],
    product: {}
}
const ProductsReducer = (state = initState, action) => {
    switch(action.type){
        case "PRODUCT": 
        return {...state, product: state.products.find(product => product.id === parseInt(action.id))}
        default: 
        return state;
    }
}
export default ProductsReducer;